Each clip is 8 seconds, 30 FPS, 240 silent MPEG-1 frames. Copy ONE profile
file to FAT USB root as xenonfin-test.m1v; do not concatenate the clips.
