# Xbox 360 acceptance checklist

## Native 0.7.5 DMA startup and ownership

The integrated 0.7.4 app failed before any media decode; standalone sound is confirmed working. 0.7.5 adds validated startup, explicit tone/music/movie leases and retained register snapshots using the original SDK driver. [Diagnosis, software evidence and cold-boot test](NATIVE_AUDIO_075.md). **The reported `00008000` status itself is empty; the earlier failing sample was not retained, so the console trigger still needs confirmation. Physical 0.7.5 tone/media output is unverified.** Older results below are historical.


## Native 0.7.4 complete audio integration

The user confirms correct sound from the 0.7.3 standalone test. Version 0.7.4 unifies standalone/tone/music/movie output through the original SDK driver and a shared checked adapter; it adds consumed-audio timestamp-origin alignment without PCM trimming, bounded recovery hysteresis and DMA/decoder diagnostics. The video/transport/demux implementations remain unchanged. [Integration and final hardware test](NATIVE_AV_074.md). **Physical 0.7.4 music/movie continuity and synchronisation remain unverified.** Earlier results below are historical.


## Native 0.7.3 audio regression rollback

Real hardware found that 0.7.2 corrupts both the PCM tone and movie audio. The sound-driver override and its control/reset changes are removed; both new ELFs link the original pinned `libxenon.a(sound.o)` used by earlier working releases. An isolated PCM ELF excludes networking/codecs/video/A/V code and measures verified sine samples and consumed-DMA timing. **First gate: clean, correctly pitched 440 Hz on the console, still pending.** [Backend comparison, diagnostics and ordered tests](NATIVE_AUDIO_073.md). Video/streaming/decoder/scheduler sources are unchanged. Historical 0.7.2 host tests did not validate the physical hardware-control assumption.


## Native 0.7.2 receive/rebuffer update

The user confirms real HDMI movie audio/video are in sync while PLAYING, but repeated rebuffering eventually ends in an HTTP idle timeout. The earlier missing 440 Hz tone was caused by active video ownership. Version 0.7.2 batches pending Ethernet RX descriptors with a bounded service budget, services networking around codec/UI work, retries reopened receive-window updates, and preserves rebuffer/TCP snapshots. It also repairs an independently verified sound-driver control-register read and provides a cooperative tone/idle reset. [Source findings, evidence and hardware procedure](NATIVE_AV_072.md). **Continuous Xbox playback and the new driver/network changes still require physical testing.** Earlier release results below are historical.


## Native 0.7.1 recovery update

Real Xbox testing found 0.7 A/V stutter and an application-generated stall/error. Version 0.7.1 fixes a deterministic frozen-master/full-video-preroll dependency, prioritises cooperative PCM refills, retains buffer capacities, and adds A/B/C comparison modes plus DMA/HTTP/PTS/stage diagnostics. [Exact cause, controls, ten-minute acceptance and test evidence](NATIVE_AV_071.md). Hardware acceptance remains pending; historical host results below cannot establish physical sound or A/V synchronisation.


**User-reported version 0.3 results:** XeLL launch, graphics/controller, audio diagnostics, Ethernet/HTTP, authentication, library discovery, movie pagination and metadata/details work on a real console. Version 0.4 adds a native MP3 pipeline, controls and reporting; **the user has now confirmed actual MP3 music works on Xbox in 0.4**. The user has since confirmed the text flicker fix. The user has now confirmed MPEG-1 decoding and CPU/GPU video in 0.5, with initially incorrect CPU colours and frame drops. The user confirmed corrected colours in 0.5.1; at 720×480/30 it presents 218/240 frames. **The user confirmed 0.5.2 at 720×480/30: 240 decoded, 240 displayed, zero drops.** [0.6 streaming acceptance](NATIVE_VIDEO_STREAMING.md) is pending. See [NATIVE_MUSIC.md](NATIVE_MUSIC.md) for the six core music test steps and fault checks. Record console model, output route, video mode, source revision, server version and track format. Video/artwork rows remain future targets.

| Check | Expected behavior | Status |
|---|---|---|
| XeLL ELF launch on Fat / Slim / E | Each supported model boots a labeled native client | Baseline boot confirmed by user; new ELF/model matrix unrun |
| 720p / 1080p output and safe area | Correct 16:9 display, readable text, no cropping | Unrun |
| Controller, sticks, hold repeat, hotplug | Correct focus and controls without keyboard | Baseline navigation confirmed; new keyboard/repeat/hotplug unrun |
| Ethernet DHCP, link loss, reconnect | Bounded timeout and recoverable connection | Baseline init/link/IP confirmed; actual DHCP ACK and new timeout/retry unrun |
| Stereo 48 kHz little-endian PCM | Clean audio on HDMI/analog routes used | Baseline audio confirmed by user; route matrix unrun |
| Initial server / hostname / base path | RAM-only numeric IPv4 HTTP in native 0.3; hostname/base path remain unsupported | Native HTTP communication confirmed in 0.2 |
| Username/password / invalid credentials | Masked entry, safe errors, no secrets in logs | Successful native login/token confirmed in 0.2; failure matrix unrun |
| Valid token restart / expiry / logout | Session reuse and reauthentication | Unrun |
| Movies / shows / seasons / episodes | Real hierarchy, metadata and 10-item pages | Movies confirmed in 0.3; TV hierarchy host-tested, console matrix unrun |
| Artists / albums / tracks | Real hierarchy, metadata and bounded neighbor fetching | Native 0.4 host-tested; console acceptance pending |
| Search / cancel / empty result | Real grouped server results, UI remains responsive | Unrun |
| Artwork / malformed image / cache churn | Correct resized images, stable memory | Unrun |
| MP3 / mono / stereo / rate conversion | Native MP3 → 48 kHz stereo S16LE; optional server MP3 transcode | Actual compressed decode and real Jellyfin host tests pass; audible MP3 output confirmed by user in 0.4; broader format matrix pending |
| Music pause / resume / stop / skip / natural advance | Responsive UI and accurate queued-PCM progress | Native 0.4 host-tested; console pending; shuffle/repeat absent |
| 480p H.264/AAC local then streamed | Sustained measured decode and A/V synchronization | Unrun |
| 720p30 Baseline / Main | Sustained measured throughput at 3–5 Mbps | Unrun |
| High profile / 1080p | Only enable if supported by measurements | Unrun |
| HEVC / multichannel / HDR transcode | Server returns decoder-compatible SDR stream | Unrun |
| Pause / seek / stop / restart | Decoder/audio/buffer state resets correctly | Unrun |
| Resume / progress reports | Position matches server within reporting interval | Unrun |
| Cable unplug / server restart / timeout | Bounded buffers and actionable recovery | Unrun |
| HTTPS valid/expired/wrong-host cert | Strict validation; no verification bypass | Unrun |
| Two-hour playback / repeated stop / library churn | No leaks, memory exhaustion or gradual drift | Unrun |

For each codec/resolution, record decoded/presented FPS, dropped/late frames, audio underruns, average/maximum video-to-audio clock error, startup and rebuffer durations, compressed-buffer occupancy, CPU utilization, peak/steady memory and network throughput. Include at least ten minutes of motion/detail-heavy material and a two-hour stability run for the chosen supported mode. Dummy audio timing on a cloud machine is not a hardware A/V measurement. A 1080p display mode does not establish 1080p decoding.

## Version 0.5 local video acceptance

Follow [NATIVE_VIDEO.md](NATIVE_VIDEO.md): FAT USB load, actual moving decoded pattern, correct aspect/colors, CPU/GPU performance counters, pause/resume, stop/return and subsequent music/library regression. 0.5 video runs on hardware; 0.5.1 colours are confirmed; 0.5.2 cadence is confirmed at 720×480/30 with 240/240 frames; broader retrace modes remain unmeasured. Test all three 30 FPS benchmark sizes, six timing pages, VSync modes, configurable lateness and the USB CSV trace. Source/build/host tests do not replace physical measurements.

## Version 0.6 streaming acceptance

Follow [NATIVE_VIDEO_STREAMING.md](NATIVE_VIDEO_STREAMING.md) for exact server requirements, movie/episode details → A, actual moving pictures, at least five minutes of continuous playback, timer/FPS/drop/underrun/PS-ES queue measurements, pause/resume, X stop/B return and server encoding cleanup. Do not count HTTP 200 alone as success. Streamed physical pictures, controls, failure recovery and five-minute stability are pending; host API/decoder tests are separate evidence. Retest MP3 sound and library/login/navigation after video.

## Version 0.7 movie sound and synchronisation

The user confirmed real 0.6 streaming at approximately 30 FPS / 720×414, zero dropped frames. Follow [NATIVE_AV.md](NATIVE_AV.md) for movie soundtrack output, actual DMA clock/PCM/rate/counters, five-minute flash/beep and dialogue measurements, joint pause/resume, short interruption/recovery, early audio tail and stop/return. Hearing both A/V does not establish synchronisation. New 0.7 sound/sync acceptance remains pending; report measured physical flash/beep offsets at start and after five minutes separately from host simulation.
