BOOT DIAGNOSTIC ONLY. Not a Jellyfin console client. ELF for an existing XeLL setup; no XEX and no hardware boot test performed. See PLATFORM.md.
