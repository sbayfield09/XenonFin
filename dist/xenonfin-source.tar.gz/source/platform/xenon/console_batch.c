/* Capture existing printf-based pages into a complete character frame. Never
 * redirect libXenon's private console_fb or suppress audio/NIC cache stores. */
#include "console_batch.h"
#include "framebuffer.h"
#include <console/console.h>
#include <stdio.h>
extern void (*stdout_hook)(const char *, int);
extern uint32_t xf_monotonic_ms(void);
static void (*boot_hook)(const char *, int);
static xf_console_frame frame;
static void capture(const char *text, int size) {
    while (size-- > 0) xf_console_putch((unsigned char)*text++);
}
int xf_console_init(void) {
    xf_console_backend backend;
    unsigned columns, rows, old_columns, old_rows;
    if (!xf_framebuffer_init(&backend, &columns, &rows)) return 0;
    console_get_dimensions(&old_columns, &old_rows);
    if (columns != old_columns || rows != old_rows || !xf_console_frame_init(&frame, columns, rows, &backend)) return 0;
    /* printf fragments and direct glyph calls must retain their order. */
    setvbuf(stdout, NULL, _IONBF, 0);
    boot_hook = stdout_hook; return 1;
}
int xf_console_ready(void) { return xf_console_frame_ready(&frame); }
void xf_console_poll(uint32_t now) { xf_console_frame_poll(&frame, now); }
void xf_console_begin(void) {
    fflush(stdout);
    if (xf_console_frame_begin(&frame, console_color[0], console_color[1])) stdout_hook = capture;
}
void xf_console_putch(unsigned char c) { xf_console_frame_putch(&frame, c, console_color[0], console_color[1]); }
int xf_console_cursor_y(void) { return (int)frame.y; }
void xf_console_end(void) {
    fflush(stdout); stdout_hook = boot_hook;
    xf_console_frame_end(&frame, xf_monotonic_ms());
}
void xf_console_shutdown(void) { stdout_hook = boot_hook; xf_framebuffer_shutdown(); }
